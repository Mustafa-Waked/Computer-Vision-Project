#testing dataset path
TEST_FOLDER = './other_dataset'


#GPU index
GPU = '4'

#batch size for testing
TEST_BATCH_SIZE = 1

# checkpoints path
SNAPSHOT_DIR = "./checkpoints"


# define the mesh resolution
GRID_W = 8
GRID_H = 6

