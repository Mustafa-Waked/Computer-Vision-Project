from copy import deepcopy
import cv2
import tensorflow as tf
import os
import numpy as np
import cv2 as cv
from cv2 import imread
from model import RectanglingNetwork
from utils import load, save, DataLoader
import constant

os.environ['CUDA_DEVICES_ORDER'] = "PCI_BUS_ID"
os.environ['CUDA_VISIBLE_DEVICES'] = constant.GPU

test_folder = constant.TRAIN_FOLDER
batch_size = constant.TRAIN_BATCH_SIZE
# grid_w = constant.GRID_W
grid_w = 6
# grid_h = constant.GRID_H
grid_h = 4


def draw_mesh_on_warp(warp, f_local):
    # f_local[3,0,0] = f_local[3,0,0] - 2
    # f_local[4,0,0] = f_local[4,0,0] - 4
    # f_local[5,0,0] = f_local[5,0,0] - 6
    # f_local[6,0,0] = f_local[6,0,0] - 8
    # f_local[6,0,1] = f_local[6,0,1] + 7

    min_w = np.minimum(np.min(f_local[:, :, 0]), 0).astype(np.int32)
    max_w = np.maximum(np.max(f_local[:, :, 0]), 512).astype(np.int32)
    min_h = np.minimum(np.min(f_local[:, :, 1]), 0).astype(np.int32)
    max_h = np.maximum(np.max(f_local[:, :, 1]), 384).astype(np.int32)

    # cw = max_w - min_w
    cw = warp.shape[1]
    # ch = max_h - min_h
    ch = warp.shape[0]

    pic = np.ones([ch + 10, cw + 10, 3], np.int32) * 255
    # x = warp[:,:,0]
    # y = warp[:,:,2]
    # warp[:,:,0] = y
    # warp[:,:,2] = x
    # pic[0-min_h+5:0-min_h+384+5, 0-min_w+5:0-min_w+512+5, :] = warp

    pic[0 - min_h + 5:0 - min_h + warp.shape[0] + 5, 0 - min_w + 5:0 - min_w + warp.shape[1] + 5, :] = warp

    warp = pic
    f_local[:, :, 0] = f_local[:, :, 0] - min_w + 5
    f_local[:, :, 1] = f_local[:, :, 1] - min_h + 5

    point_color = (0, 255, 0)  # BGR
    thickness = 2
    lineType = 8
    # cv.circle(warp, (60, 0), 60, point_color, 0)
    # cv.circle(warp, (f_local[0,0,0], f_local[0,0,1]), 5, point_color, 0)
    num = 1
    for i in range(grid_h + 1):
        for j in range(grid_w + 1):
            # cv.putText(warp, str(num), (f_local[i,j,0], f_local[i,j,1]), cv.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
            num = num + 1
            if j == grid_w and i == grid_h:
                continue
            elif j == grid_w:
                cv.line(warp, (f_local[i, j, 0], f_local[i, j, 1]), (f_local[i + 1, j, 0], f_local[i + 1, j, 1]),
                        point_color, thickness, lineType)
            elif i == grid_h:
                cv.line(warp, (f_local[i, j, 0], f_local[i, j, 1]), (f_local[i, j + 1, 0], f_local[i, j + 1, 1]),
                        point_color, thickness, lineType)
            else:
                cv.line(warp, (f_local[i, j, 0], f_local[i, j, 1]), (f_local[i + 1, j, 0], f_local[i + 1, j, 1]),
                        point_color, thickness, lineType)
                cv.line(warp, (f_local[i, j, 0], f_local[i, j, 1]), (f_local[i, j + 1, 0], f_local[i, j + 1, 1]),
                        point_color, thickness, lineType)

    return warp


snapshot_dir = './checkpoints/pretrained_model/model.ckpt-100000'

# define dataset
with tf.name_scope('dataset'):
    ##########testing###############
    test_inputs_clips_tensor = tf.placeholder(shape=[batch_size, None, None, 3 * 3], dtype=tf.float32)

    test_input = test_inputs_clips_tensor[..., 0:3]
    test_mask = test_inputs_clips_tensor[..., 3:6]
    test_gt = test_inputs_clips_tensor[..., 6:9]

    print('test input = {}'.format(test_input))
    print('test mask = {}'.format(test_mask))
    print('test gt = {}'.format(test_gt))

# define testing generator function
with tf.variable_scope('generator', reuse=None):
    print('testing = {}'.format(tf.get_variable_scope().name))
    test_mesh_primary, test_warp_image_primary, test_warp_mask_primary, test_mesh_final, test_warp_image_final, test_warp_mask_final = RectanglingNetwork(
        test_input, test_mask)

config = tf.ConfigProto()
config.gpu_options.allow_growth = True
with tf.Session(config=config) as sess:
    # dataset
    input_loader = DataLoader(test_folder)

    # initialize weights
    sess.run(tf.global_variables_initializer())
    print('Init global successfully!')

    # tf saver
    saver = tf.train.Saver(var_list=tf.global_variables(), max_to_keep=None)

    restore_var = [v for v in tf.global_variables()]
    loader = tf.train.Saver(var_list=restore_var)


    def regCropAndScale(regular_image, mesh, idx):
        nx, ny = (9, 7)
        height, width = 384, 512
        x = np.linspace(0, width, nx)
        y = np.linspace(0, height, ny)
        xv, yv = np.meshgrid(x, y)
        reg = deepcopy(mesh)
        for i in range(7):
            for j in range(9):
                reg[i][j][0] = xv[i][j]
                reg[i][j][1] = yv[i][j]
        reg = reg.astype(np.int32)
        reg_cropped = regular_image[reg[1, 1, 1]:reg[5, 1, 1], reg[1, 1, 0]:reg[1, 7, 0]]
        scaled = cv2.resize(reg_cropped, (width, height))
        path1 = "../data_augmentation/final_res/gt/" + str(idx + 1).zfill(5) + ".jpg"
        cv.imwrite(path1, scaled)

    def cropAndScale(image, mesh, idx):
        height, width = 384, 512
        whitemask = deepcopy(image)
        for i in range(image.shape[0]):
            for j in range(image.shape[1]):
                whitemask[i][j] = 255

        roi_corners = np.array(
            [[(mesh[1, 1, 0], mesh[1, 1, 1]), (mesh[1, 2, 0], mesh[1, 2, 1]), (mesh[1, 3, 0], mesh[1, 3, 1]),
              (mesh[1, 4, 0], mesh[1, 4, 1]), (mesh[1, 5, 0], mesh[1, 5, 1]), (mesh[1, 6, 0], mesh[1, 6, 1]),
              (mesh[1, 7, 0], mesh[1, 7, 1]), (mesh[2, 7, 0], mesh[2, 7, 1]), (mesh[3, 7, 0], mesh[3, 7, 1]),
              (mesh[4, 7, 0], mesh[4, 7, 1]), (mesh[5, 7, 0], mesh[5, 7, 1]), (mesh[5, 6, 0], mesh[5, 6, 1]),
              (mesh[5, 4, 0], mesh[5, 4, 1]), (mesh[5, 3, 0], mesh[5, 3, 1]), (mesh[5, 2, 0], mesh[5, 2, 1]),
              (mesh[5, 1, 0], mesh[5, 1, 1])]], dtype=np.int32)
        mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
        cv2.fillPoly(mask, roi_corners, 255)
        masked_image = cv2.bitwise_and(image, image, mask=mask)

        cropped_mask = mask[min(int(mesh[1, 1, 1]), int(mesh[1,7,1])):max(int(mesh[5, 1, 1]), int(mesh[5, 7, 1])),
                               min(int(mesh[1, 1, 0]), int(mesh[5,1,0])):max(int(mesh[1, 7, 0]), int(mesh[5, 7, 0]))]
        scaled_mask = cv2.resize(cropped_mask, (width, height))
        path1 = "../data_augmentation/final_res/mask/" + str(idx + 1).zfill(5) + ".jpg"
        cv.imwrite(path1, scaled_mask)

        cropped = masked_image[min(int(mesh[1, 1, 1]), int(mesh[1, 7, 1])):max(int(mesh[5, 1, 1]), int(mesh[5, 7, 1])),
                  min(int(mesh[1, 1, 0]), int(mesh[5, 1, 0])):max(int(mesh[1, 7, 0]), int(mesh[5, 7, 0]))]
        scaled = cv2.resize(cropped, (width, height))
        path1 = "../data_augmentation/final_res/input/" + str(idx + 1).zfill(5) + ".jpg"
        cv.imwrite(path1, scaled)


    def inference_func(ckpt):
        print("============")
        print(ckpt)
        load(loader, sess, ckpt)
        print("============")
        length = len(os.listdir(test_folder+"/input"))
        psnr_list = []
        ssim_list = []

        for i in range(0, length):
            input_clip = np.expand_dims(input_loader.get_data_clips(i), axis=0)

            mesh_primary, warp_image_primary, warp_mask_primary, mesh_final, warp_image_final, warp_mask_final = sess.run(
                [test_mesh_primary, test_warp_image_primary, test_warp_mask_primary, test_mesh_final,
                 test_warp_image_final, test_warp_mask_final], feed_dict={test_inputs_clips_tensor: input_clip})

            mesh = mesh_final[0]

            input_image = (input_clip[0, :, :, 0:3] + 1) / 2 * 255
            regular_image = (input_clip[0, :, :, 6:9] + 1) / 2 * 255
            regCropAndScale(regular_image, mesh, i)
            cropAndScale(input_image, mesh, i)

            # input_image = draw_mesh_on_warp(input_image, mesh)
            # input_mask = draw_mesh_on_warp(np.ones([384, 512, 3], np.int32)*255, mesh)

            # path = "../final_mesh/" + str(i + 1).zfill(5) + ".jpg"
            # cv.imwrite(path, input_image)

            # path = "../mesh_mask/" + str(i+1).zfill(5) + ".jpg"
            # cv.imwrite(path, input_mask)

            print('i = {} / {}'.format(i + 1, length))


    inference_func(snapshot_dir)





